<?php
    $host_db="localhost";
    $user_db="root";
    $pass_db="";
    $nama_db="bestore-main";    
    $mysqli = new mysqli($host_db,$user_db,$pass_db,$nama_db);
?>