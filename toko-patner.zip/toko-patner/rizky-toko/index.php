<?php 
                    $id_patner = 20091;
                ?>
                <base href='../../'>
                <?php
                require 'template/head.php';
                require 'template/body.php';
                require 'template/footer.php'; 
                ?>
