<?php
  session_start();
  if (!isset($_SESSION['adm'])) {
    header("Location:login");
  }
?>
<!DOCTYPE html>
<!--
Template Name: Materialize - Material Design Admin Template
Author: PixInvent
Website: http://www.pixinvent.com/
Contact: hello@pixinvent.com
Follow: www.twitter.com/pixinvents
Like: www.facebook.com/pixinvents
Purchase: https://themeforest.net/item/materialize-material-design-admin-template/11446068?ref=pixinvent
Renew Support: https://themeforest.net/item/materialize-material-design-admin-template/11446068?ref=pixinvent
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.


-->
<html class="loading" lang="en" data-textdirection="ltr">
<?php
    $index = 'active';
    require 'head.php';
?>

<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="col s12">
      <div class="container">
        <div class="section">

          <div class="row">
            <div class="col s12 m6 l8">
              <div class="card subscriber-list-card animate fadeRight">
                <div class="card-content pb-1">
                  <h4 class="card-title mb-0">List Toko <i class="material-icons float-right">more_vert</i></h4>
                </div>
                <table class="subscription-table responsive-table highlight">
                  <thead>
                    <tr>
                      <th>Nama Toko</th>
                      <th>Nama Penjual</th>
                      <th>Sub-Domain</th>
                      <th>Tanggal Dibuat</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Michael Austin</td>
                      <td>ABC Fintech LTD.</td>
                      <td>rizky-gaming</td>
                      <td>Jan 1,2019</td>
                      <td><span class="badge green lighten-5 green-text text-accent-4">ARMY</span></td>
                      <td class="center-align"><a href="#"><i class="material-icons pink-text">clear</i></a></td>
                    </tr>
                    <tr>
                      <td>Aldin Rakić</td>
                      <td>ACME Pvt LTD.</td>
                      <td>michael-store</td>
                      <td>Jan 10,2019</td>
                      <td><span class="badge green lighten-5 green-text text-accent-4">QUEEN</span></td>
                      <td class="center-align"><a href="#"><i class="material-icons pink-text">clear</i></a></td>
                    </tr>
                    <tr>
                      <td>İris Yılmaz</td>
                      <td>Collboy Tech LTD.</td>
                      <td>katsurishop</td>
                      <td>Jan 12,2019</td>
                      <td><span class="badge green lighten-5 green-text text-accent-4">DRONE</span></td>
                      <td class="center-align"><a href="#"><i class="material-icons pink-text">clear</i></a></td>
                    </tr>
                    <tr>
                      <td>Lidia Livescu</td>
                      <td>My Fintech LTD.</td>
                      <td>fintech</td>
                      <td>Jan 14,2019</td>
                      <td><span class="badge pink lighten-5 pink-text text-accent-2">FREE</span></td>
                      <td class="center-align"><a href="#"><i class="material-icons pink-text">clear</i></a></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col s12 m6 l4">
              <div class="card padding-4 animate fadeLeft">
                <div class="row">
                  <div class="col s5 m5">
                    <h5 class="mb-0">1885</h5>
                    <p class="no-margin">New</p>
                    <p class="mb-0 pt-8">1,12,900</p>
                  </div>
                  <div class="col s7 m7 right-align">
                    <i
                      class="material-icons background-round mt-5 mb-5 gradient-45deg-purple-amber gradient-shadow white-text">perm_identity</i>
                    <p class="mb-0">Total Clients</p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div><!-- START RIGHT SIDEBAR NAV -->
        <aside id="right-sidebar-nav">
          <div id="slide-out-right" class="slide-out-right-sidenav sidenav rightside-navigation">
            <div class="row">
              <div class="slide-out-right-title">
                <div class="col s12 border-bottom-1 pb-0 pt-1">
                  <div class="row">
                    <div class="col s2 pr-0 center">
                      <i class="material-icons vertical-text-middle"><a href="#" class="sidenav-close">clear</a></i>
                    </div>
                    <div class="col s10 pl-0">
                      <ul class="tabs">
                        <li class="tab col s4 p-0">
                          <a href="#messages" class="active">
                            <span>Messages</span>
                          </a>
                        </li>
                        <li class="tab col s4 p-0">
                          <a href="#settings">
                            <span>Settings</span>
                          </a>
                        </li>
                        <li class="tab col s4 p-0">
                          <a href="#activity">
                            <span>Activity</span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="slide-out-right-body row pl-3">
                <div id="messages" class="col s12 pb-0">
                  <div class="collection border-none mb-0">
                    <input class="header-search-input mt-4 mb-2" type="text" name="Search"
                      placeholder="Search Messages" />
                    <ul class="collection right-sidebar-chat p-0 mb-0">
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Elizabeth Elliott</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Thank you</p>
                        </div>
                        <span class="secondary-content medium-small">5.00 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-1.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Mary Adams</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Hello Boo</p>
                        </div>
                        <span class="secondary-content medium-small">4.14 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-2.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Caleb Richards</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Hello Boo</p>
                        </div>
                        <span class="secondary-content medium-small">4.14 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-3.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Caleb Richards</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Keny !</p>
                        </div>
                        <span class="secondary-content medium-small">9.00 PM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-4.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">June Lane</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Ohh God</p>
                        </div>
                        <span class="secondary-content medium-small">4.14 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-5.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Edward Fletcher</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Love you</p>
                        </div>
                        <span class="secondary-content medium-small">5.15 PM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-6.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Crystal Bates</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Can we</p>
                        </div>
                        <span class="secondary-content medium-small">8.00 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Nathan Watts</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Great!</p>
                        </div>
                        <span class="secondary-content medium-small">9.53 PM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-8.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Willard Wood</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Do it</p>
                        </div>
                        <span class="secondary-content medium-small">4.20 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-1.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Ronnie Ellis</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Got that</p>
                        </div>
                        <span class="secondary-content medium-small">5.20 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-9.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Daniel Russell</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Thank you</p>
                        </div>
                        <span class="secondary-content medium-small">12.00 AM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-10.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Sarah Graves</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Okay you</p>
                        </div>
                        <span class="secondary-content medium-small">11.14 PM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-off avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-11.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Andrew Hoffman</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Can do</p>
                        </div>
                        <span class="secondary-content medium-small">7.30 PM</span>
                      </li>
                      <li class="collection-item right-sidebar-chat-item sidenav-trigger display-flex avatar pl-5 pb-0"
                        data-target="slide-out-chat">
                        <span class="avatar-status avatar-online avatar-50"><img
                            src="../../../app-assets/images/avatar/avatar-12.png" alt="avatar" />
                          <i></i>
                        </span>
                        <div class="user-content">
                          <h6 class="line-height-0">Camila Lynch</h6>
                          <p class="medium-small blue-grey-text text-lighten-3 pt-3">Leave it</p>
                        </div>
                        <span class="secondary-content medium-small">2.00 PM</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div id="settings" class="col s12">
                  <p class="setting-header mt-8 mb-3 ml-5 font-weight-900">GENERAL SETTINGS</p>
                  <ul class="collection border-none">
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Notifications</span>
                        <div class="switch right">
                          <label>
                            <input checked type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Show recent activity</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Show recent activity</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Show Task statistics</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Show your emails</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Email Notifications</span>
                        <div class="switch right">
                          <label>
                            <input checked type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                  </ul>
                  <p class="setting-header mt-7 mb-3 ml-5 font-weight-900">SYSTEM SETTINGS</p>
                  <ul class="collection border-none">
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>System Logs</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Error Reporting</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Applications Logs</span>
                        <div class="switch right">
                          <label>
                            <input checked type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Backup Servers</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                    <li class="collection-item border-none">
                      <div class="m-0">
                        <span>Audit Logs</span>
                        <div class="switch right">
                          <label>
                            <input type="checkbox" />
                            <span class="lever"></span>
                          </label>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div id="activity" class="col s12">
                  <div class="activity">
                    <p class="mt-5 mb-0 ml-5 font-weight-900">SYSTEM LOGS</p>
                    <ul class="widget-timeline mb-0">
                      <li class="timeline-items timeline-icon-green active">
                        <div class="timeline-time">Today</div>
                        <h6 class="timeline-title">Homepage mockup design</h6>
                        <p class="timeline-text">Melissa liked your activity.</p>
                        <div class="timeline-content orange-text">Important</div>
                      </li>
                      <li class="timeline-items timeline-icon-cyan active">
                        <div class="timeline-time">10 min</div>
                        <h6 class="timeline-title">Melissa liked your activity Drinks.</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content green-text">Resolved</div>
                      </li>
                      <li class="timeline-items timeline-icon-red active">
                        <div class="timeline-time">30 mins</div>
                        <h6 class="timeline-title">12 new users registered</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content">
                          <img src="../../../app-assets/images/icon/pdf.png" alt="document" height="30" width="25"
                            class="mr-1">Registration.doc
                        </div>
                      </li>
                      <li class="timeline-items timeline-icon-indigo active">
                        <div class="timeline-time">2 Hrs</div>
                        <h6 class="timeline-title">Tina is attending your activity</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content">
                          <img src="../../../app-assets/images/icon/pdf.png" alt="document" height="30" width="25"
                            class="mr-1">Activity.doc
                        </div>
                      </li>
                      <li class="timeline-items timeline-icon-orange">
                        <div class="timeline-time">5 hrs</div>
                        <h6 class="timeline-title">Josh is now following you</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content red-text">Pending</div>
                      </li>
                    </ul>
                    <p class="mt-5 mb-0 ml-5 font-weight-900">APPLICATIONS LOGS</p>
                    <ul class="widget-timeline mb-0">
                      <li class="timeline-items timeline-icon-green active">
                        <div class="timeline-time">Just now</div>
                        <h6 class="timeline-title">New order received urgent</h6>
                        <p class="timeline-text">Melissa liked your activity.</p>
                        <div class="timeline-content orange-text">Important</div>
                      </li>
                      <li class="timeline-items timeline-icon-cyan active">
                        <div class="timeline-time">05 min</div>
                        <h6 class="timeline-title">System shutdown.</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content blue-text">Urgent</div>
                      </li>
                      <li class="timeline-items timeline-icon-red">
                        <div class="timeline-time">20 mins</div>
                        <h6 class="timeline-title">Database overloaded 89%</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content">
                          <img src="../../../app-assets/images/icon/pdf.png" alt="document" height="30" width="25"
                            class="mr-1">Database-log.doc
                        </div>
                      </li>
                    </ul>
                    <p class="mt-5 mb-0 ml-5 font-weight-900">SERVER LOGS</p>
                    <ul class="widget-timeline mb-0">
                      <li class="timeline-items timeline-icon-green active">
                        <div class="timeline-time">10 min</div>
                        <h6 class="timeline-title">System error</h6>
                        <p class="timeline-text">Melissa liked your activity.</p>
                        <div class="timeline-content red-text">Error</div>
                      </li>
                      <li class="timeline-items timeline-icon-cyan">
                        <div class="timeline-time">1 min</div>
                        <h6 class="timeline-title">Production server down.</h6>
                        <p class="timeline-text">Here are some news feed interactions concepts.</p>
                        <div class="timeline-content blue-text">Urgent</div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide Out Chat -->
          <ul id="slide-out-chat" class="sidenav slide-out-right-sidenav-chat">
            <li class="center-align pt-2 pb-2 sidenav-close chat-head">
              <a href="#!"><i class="material-icons mr-0">chevron_left</i>Elizabeth Elliott</a>
            </li>
            <li class="chat-body">
              <ul class="collection">
                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">hello!</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">How can we help? We're here for you!</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">I am looking for the best admin template.?</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">Materialize admin is the responsive materializecss admin template.</p>
                  </div>
                </li>

                <li class="collection-item display-grid width-100 center-align">
                  <p>8:20 a.m.</p>
                </li>

                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">Ohh! very nice</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">Thank you.</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">How can I purchase it?</p>
                  </div>
                </li>

                <li class="collection-item display-grid width-100 center-align">
                  <p>9:00 a.m.</p>
                </li>

                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">From ThemeForest.</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">Only $24</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">Ohh! Thank you.</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar pl-5 pb-0" data-target="slide-out-chat">
                  <span class="avatar-status avatar-online avatar-50"><img
                      src="../../../app-assets/images/avatar/avatar-7.png" alt="avatar" />
                  </span>
                  <div class="user-content speech-bubble">
                    <p class="medium-small">I will purchase it for sure.</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">Great, Feel free to get in touch on</p>
                  </div>
                </li>
                <li class="collection-item display-flex avatar justify-content-end pl-5 pb-0"
                  data-target="slide-out-chat">
                  <div class="user-content speech-bubble-right">
                    <p class="medium-small">https://pixinvent.ticksy.com/</p>
                  </div>
                </li>
              </ul>
            </li>
            <li class="center-align chat-footer">
              <form class="col s12" onsubmit="slideOutChat()" action="javascript:void(0);">
                <div class="input-field">
                  <input id="icon_prefix" type="text" class="search" />
                  <label for="icon_prefix">Type here..</label>
                  <a onclick="slideOutChat()"><i class="material-icons prefix">send</i></a>
                </div>
              </form>
            </li>
          </ul>
        </aside>
        <!-- END RIGHT SIDEBAR NAV -->
        <!-- Intro -->

        <div id="intro">
          <div class="row">
            <div class="col s12">

              <div id="img-modal" class="modal white">
                <div class="modal-content">
                  <div class="bg-img-div"></div>
                  <p class="modal-header right modal-close">
                    Skip Intro <span class="right"><i class="material-icons right-align">clear</i></span>
                  </p>
                  <div class="carousel carousel-slider center intro-carousel">
                    <div class="carousel-fixed-item center middle-indicator">
                      <div class="left">
                        <button
                          class="movePrevCarousel middle-indicator-text btn btn-flat purple-text waves-effect waves-light btn-prev">
                          <i class="material-icons">navigate_before</i> <span class="hide-on-small-only">Prev</span>
                        </button>
                      </div>

                      <div class="right">
                        <button
                          class=" moveNextCarousel middle-indicator-text btn btn-flat purple-text waves-effect waves-light btn-next">
                          <span class="hide-on-small-only">Next</span> <i class="material-icons">navigate_next</i>
                        </button>
                      </div>
                    </div>
                    <div class="carousel-item slide-1">
                      <img src="../../../app-assets/images/gallery/intro-slide-1.png" alt=""
                        class="responsive-img animated fadeInUp slide-1-img">
                      <h5 class="intro-step-title mt-7 center animated fadeInUp">Welcome to Materialize</h5>
                      <p class="intro-step-text mt-5 animated fadeInUp">Materialize is a Material Design Admin
                        Template is the excellent responsive google material design inspired multipurpose admin
                        template. Materialize has a huge collection of material design animation & widgets, UI
                        Elements.</p>
                    </div>
                    <div class="carousel-item slide-2">
                      <img src="../../../app-assets/images/gallery/intro-features.png" alt=""
                        class="responsive-img slide-2-img">
                      <h5 class="intro-step-title mt-7 center">Example Request Information</h5>
                      <p class="intro-step-text mt-5">Lorem ipsum dolor sit amet consectetur,
                        adipisicing elit.
                        Aperiam deserunt nulla
                        repudiandae odit quisquam incidunt, maxime explicabo.</p>
                      <div class="row">
                        <div class="col s6">
                          <div class="input-field">
                            <label for="first_name">Name</label>
                            <input placeholder="Name" id="first_name" type="text" class="validate">
                          </div>
                        </div>
                        <div class="col s6">
                          <div class="input-field">
                            <select>
                              <option value="" disabled selected>Choose your option</option>
                              <option value="1">Option 1</option>
                              <option value="2">Option 2</option>
                              <option value="3">Option 3</option>
                            </select>
                            <label>Materialize Select</label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="carousel-item slide-3">
                      <img src="../../../app-assets/images/gallery/intro-app.png" alt=""
                        class="responsive-img slide-1-img">
                      <h5 class="intro-step-title mt-7 center">Showcase App Features</h5>
                      <div class="row">
                        <div class="col m5 offset-m1 s12">
                          <ul class="feature-list left-align">
                            <li><i class="material-icons">check</i> Email Application</li>
                            <li><i class="material-icons">check</i> Chat Application</li>
                            <li><i class="material-icons">check</i> Todo Application</li>
                          </ul>
                        </div>
                        <div class="col m6 s12">
                          <ul class="feature-list left-align">
                            <li><i class="material-icons">check</i>Contacts Application</li>
                            <li><i class="material-icons">check</i>Full Calendar</li>
                            <li><i class="material-icons">check</i> Ecommerce Application</li>
                          </ul>
                        </div>
                        <div class="row">
                          <div class="col s12 center">
                            <button
                              class="get-started btn waves-effect waves-light gradient-45deg-purple-deep-orange mt-3 modal-close">Get
                              Started</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- / Intro -->
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->

<!-- Theme Customizer -->

<a href="#" data-target="theme-cutomizer-out"
  class="btn btn-customizer pink accent-2 white-text sidenav-trigger theme-cutomizer-trigger"><i
    class="material-icons">settings</i></a>

<div id="theme-cutomizer-out" class="theme-cutomizer sidenav row">
  <div class="col s12">
    <a class="sidenav-close" href="#!"><i class="material-icons">close</i></a>
    <h5 class="theme-cutomizer-title">Theme Customizer</h5>
    <p class="medium-small">Customize & Preview in Real Time</p>
    <div class="menu-options">
      <h6 class="mt-6">Menu Options</h6>
      <hr class="customize-devider" />
      <div class="menu-options-form row">
        <div class="input-field col s12 menu-color mb-0">
          <p class="mt-0">Menu Color</p>
          <div class="gradient-color center-align">
            <span class="menu-color-option gradient-45deg-indigo-blue" data-color="gradient-45deg-indigo-blue"></span>
            <span class="menu-color-option gradient-45deg-purple-deep-orange"
              data-color="gradient-45deg-purple-deep-orange"></span>
            <span class="menu-color-option gradient-45deg-light-blue-cyan"
              data-color="gradient-45deg-light-blue-cyan"></span>
            <span class="menu-color-option gradient-45deg-purple-amber" data-color="gradient-45deg-purple-amber"></span>
            <span class="menu-color-option gradient-45deg-purple-deep-purple"
              data-color="gradient-45deg-purple-deep-purple"></span>
            <span class="menu-color-option gradient-45deg-deep-orange-orange"
              data-color="gradient-45deg-deep-orange-orange"></span>
            <span class="menu-color-option gradient-45deg-green-teal" data-color="gradient-45deg-green-teal"></span>
            <span class="menu-color-option gradient-45deg-indigo-light-blue"
              data-color="gradient-45deg-indigo-light-blue"></span>
            <span class="menu-color-option gradient-45deg-red-pink" data-color="gradient-45deg-red-pink"></span>
          </div>
          <div class="solid-color center-align">
            <span class="menu-color-option red" data-color="red"></span>
            <span class="menu-color-option purple" data-color="purple"></span>
            <span class="menu-color-option pink" data-color="pink"></span>
            <span class="menu-color-option deep-purple" data-color="deep-purple"></span>
            <span class="menu-color-option cyan" data-color="cyan"></span>
            <span class="menu-color-option teal" data-color="teal"></span>
            <span class="menu-color-option light-blue" data-color="light-blue"></span>
            <span class="menu-color-option amber darken-3" data-color="amber darken-3"></span>
            <span class="menu-color-option brown darken-2" data-color="brown darken-2"></span>
          </div>
        </div>
        <div class="input-field col s12 menu-bg-color mb-0">
          <p class="mt-0">Menu Background Color</p>
          <div class="gradient-color center-align">
            <span class="menu-bg-color-option gradient-45deg-indigo-blue"
              data-color="gradient-45deg-indigo-blue"></span>
            <span class="menu-bg-color-option gradient-45deg-purple-deep-orange"
              data-color="gradient-45deg-purple-deep-orange"></span>
            <span class="menu-bg-color-option gradient-45deg-light-blue-cyan"
              data-color="gradient-45deg-light-blue-cyan"></span>
            <span class="menu-bg-color-option gradient-45deg-purple-amber"
              data-color="gradient-45deg-purple-amber"></span>
            <span class="menu-bg-color-option gradient-45deg-purple-deep-purple"
              data-color="gradient-45deg-purple-deep-purple"></span>
            <span class="menu-bg-color-option gradient-45deg-deep-orange-orange"
              data-color="gradient-45deg-deep-orange-orange"></span>
            <span class="menu-bg-color-option gradient-45deg-green-teal" data-color="gradient-45deg-green-teal"></span>
            <span class="menu-bg-color-option gradient-45deg-indigo-light-blue"
              data-color="gradient-45deg-indigo-light-blue"></span>
            <span class="menu-bg-color-option gradient-45deg-red-pink" data-color="gradient-45deg-red-pink"></span>
          </div>
          <div class="solid-color center-align">
            <span class="menu-bg-color-option red" data-color="red"></span>
            <span class="menu-bg-color-option purple" data-color="purple"></span>
            <span class="menu-bg-color-option pink" data-color="pink"></span>
            <span class="menu-bg-color-option deep-purple" data-color="deep-purple"></span>
            <span class="menu-bg-color-option cyan" data-color="cyan"></span>
            <span class="menu-bg-color-option teal" data-color="teal"></span>
            <span class="menu-bg-color-option light-blue" data-color="light-blue"></span>
            <span class="menu-bg-color-option amber darken-3" data-color="amber darken-3"></span>
            <span class="menu-bg-color-option brown darken-2" data-color="brown darken-2"></span>
          </div>
        </div>
        <div class="input-field col s12">
          <div class="switch">
            Menu Dark
            <label class="float-right"><input class="menu-dark-checkbox" type="checkbox" /> <span
                class="lever ml-0"></span></label>
          </div>
        </div>
        <div class="input-field col s12">
          <div class="switch">
            Menu Collapsed
            <label class="float-right"><input class="menu-collapsed-checkbox" type="checkbox" /> <span
                class="lever ml-0"></span></label>
          </div>
        </div>
        <div class="input-field col s12">
          <div class="switch">
            <p class="mt-0">Menu Selection</p>
            <label>
              <input class="menu-selection-radio with-gap" value="sidenav-active-square" name="menu-selection"
                type="radio" />
              <span>Square</span>
            </label>
            <label>
              <input class="menu-selection-radio with-gap" value="sidenav-active-rounded" name="menu-selection"
                type="radio" />
              <span>Rounded</span>
            </label>
            <label>
              <input class="menu-selection-radio with-gap" value="" name="menu-selection" type="radio" />
              <span>Normal</span>
            </label>
          </div>
        </div>
      </div>
    </div>
    <h6 class="mt-6">Navbar Options</h6>
    <hr class="customize-devider" />
    <div class="navbar-options row">
      <div class="input-field col s12 navbar-color mb-0">
        <p class="mt-0">Navbar Color</p>
        <div class="gradient-color center-align">
          <span class="navbar-color-option gradient-45deg-indigo-blue" data-color="gradient-45deg-indigo-blue"></span>
          <span class="navbar-color-option gradient-45deg-purple-deep-orange"
            data-color="gradient-45deg-purple-deep-orange"></span>
          <span class="navbar-color-option gradient-45deg-light-blue-cyan"
            data-color="gradient-45deg-light-blue-cyan"></span>
          <span class="navbar-color-option gradient-45deg-purple-amber" data-color="gradient-45deg-purple-amber"></span>
          <span class="navbar-color-option gradient-45deg-purple-deep-purple"
            data-color="gradient-45deg-purple-deep-purple"></span>
          <span class="navbar-color-option gradient-45deg-deep-orange-orange"
            data-color="gradient-45deg-deep-orange-orange"></span>
          <span class="navbar-color-option gradient-45deg-green-teal" data-color="gradient-45deg-green-teal"></span>
          <span class="navbar-color-option gradient-45deg-indigo-light-blue"
            data-color="gradient-45deg-indigo-light-blue"></span>
          <span class="navbar-color-option gradient-45deg-red-pink" data-color="gradient-45deg-red-pink"></span>
        </div>
        <div class="solid-color center-align">
          <span class="navbar-color-option red" data-color="red"></span>
          <span class="navbar-color-option purple" data-color="purple"></span>
          <span class="navbar-color-option pink" data-color="pink"></span>
          <span class="navbar-color-option deep-purple" data-color="deep-purple"></span>
          <span class="navbar-color-option cyan" data-color="cyan"></span>
          <span class="navbar-color-option teal" data-color="teal"></span>
          <span class="navbar-color-option light-blue" data-color="light-blue"></span>
          <span class="navbar-color-option amber darken-3" data-color="amber darken-3"></span>
          <span class="navbar-color-option brown darken-2" data-color="brown darken-2"></span>
        </div>
      </div>
      <div class="input-field col s12">
        <div class="switch">
          Navbar Dark
          <label class="float-right"><input class="navbar-dark-checkbox" type="checkbox" /> <span
              class="lever ml-0"></span></label>
        </div>
      </div>
      <div class="input-field col s12">
        <div class="switch">
          Navbar Fixed
          <label class="float-right"><input class="navbar-fixed-checkbox" type="checkbox" checked /> <span
              class="lever ml-0"></span></label>
        </div>
      </div>
    </div>
    <h6 class="mt-6">Footer Options</h6>
    <hr class="customize-devider" />
    <div class="navbar-options row">
      <div class="input-field col s12">
        <div class="switch">
          Footer Dark
          <label class="float-right"><input class="footer-dark-checkbox" type="checkbox" /> <span
              class="lever ml-0"></span></label>
        </div>
      </div>
      <div class="input-field col s12">
        <div class="switch">
          Footer Fixed
          <label class="float-right"><input class="footer-fixed-checkbox" type="checkbox" /> <span
              class="lever ml-0"></span></label>
        </div>
      </div>
    </div>
  </div>
</div>
<!--/ Theme Customizer -->

<a href="https://1.envato.market/materialize_admin" target="_blank"
  class="btn btn-buy-now gradient-45deg-indigo-purple gradient-shadow white-text tooltipped buy-now-animated tada"
  data-position="left" data-tooltip="Buy Now!"><i class="material-icons">add_shopping_cart</i></a>

<!-- BEGIN: Footer-->

<footer
  class="page-footer footer footer-static footer-dark gradient-45deg-indigo-purple gradient-shadow navbar-border navbar-shadow">
  <div class="footer-copyright">
    <div class="container"><span>&copy; 2020 <a href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent"
          target="_blank">PIXINVENT</a> All rights reserved.</span><span class="right hide-on-small-only">Design and
        Developed by <a href="https://pixinvent.com/">PIXINVENT</a></span></div>
  </div>
</footer>

<!-- END: Footer-->
<!-- BEGIN VENDOR JS-->
<script src="../../../app-assets/js/vendors.min.js"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="../../../app-assets/vendors/chartjs/chart.min.js"></script>
<script src="../../../app-assets/vendors/chartist-js/chartist.min.js"></script>
<script src="../../../app-assets/vendors/chartist-js/chartist-plugin-tooltip.js"></script>
<script src="../../../app-assets/vendors/chartist-js/chartist-plugin-fill-donut.min.js"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="../../../app-assets/js/plugins.js"></script>
<script src="../../../app-assets/js/search.js"></script>
<script src="../../../app-assets/js/custom/custom-script.js"></script>
<script src="../../../app-assets/js/scripts/customizer.js"></script>
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="../../../app-assets/js/scripts/dashboard-modern.js"></script>
<!-- <script src="../../../app-assets/js/scripts/intro.js"></script> -->
<!-- END PAGE LEVEL JS-->
</body>

</html>