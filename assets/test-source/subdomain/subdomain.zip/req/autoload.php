<?php

require_once 'req/composer/autoload_real.php';

return ComposerAutoloaderInit644c83419fc62d8209f43797f3f33f10::getLoader();